<?php
require_once __DIR__ . '/classes/Template.php';
Template::header('Drink shop');
?>

<div class="about">
<h2>About us</h2>
<p> Lorem ipsum dolor sit amet consectetur adipisicing elit.
    Eum obcaecati magnam et laudantium commodi suscipit natus eius sit
    ullam necessitatibus, tempora eveniet placeat harum deleniti doloremque
    iusto in odit repellendus.
</p>
</div>

<?php
Template::footer();